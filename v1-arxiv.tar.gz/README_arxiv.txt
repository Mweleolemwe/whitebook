arXiv-ready bundle (pdflatex-safe)
=================================

Files:
- nse_ledger_preprint_final.tex  (main paper)
- ledger_timeseries.png          (figure placeholder; replace with your generated plot)
Build:
    pdflatex nse_ledger_preprint_final.tex
    pdflatex nse_ledger_preprint_final.tex

Notes:
- This bundle is pdflatex-safe for arXiv; fonts via lmodern, \pdfoutput=1 set.
- Replace the placeholder figure with the real ledger_timeseries.png from your DOI archive.
- Keep hyperlinks to the replication DOI in place for reproducibility.
